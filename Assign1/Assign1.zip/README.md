# CMPUT379 Assign 1
Brady Pomerleau & Brady Thompson

Brady Pomerleau: I wrote every line of code of this program. Brady Thompson was hard to get a hold of
					and he put very little time into this project. I feel bad throwing him under the 
					bus like this but he really was that bad. He didn't attempt to write a single
					line of code until Thrus Feb 01 at around 7 pm. As far as I know he didn't work
					on it for very long and in any case he never made the code available to me and 
					stopped responding to emails until 9 am Feb 02. 10 am he uploaded an incomplete 
					solution to GitHub (private repo, don't worry). By then my solution was already
					better than his. So I finished mine, and here it is. 

This code runs successfully on the VM distributed on eclass.